#!/bin/bash
# 
# This script is used to install DSC on Linux.
# 
