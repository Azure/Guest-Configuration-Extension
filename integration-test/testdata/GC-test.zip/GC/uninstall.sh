#!/bin/bash
# 
# This script disables DSC on Linux by stopping the DSC service.
# 

echo "Running Uninstall"
exit 0