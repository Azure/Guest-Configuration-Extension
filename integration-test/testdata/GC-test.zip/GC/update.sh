#!/bin/bash
# 
# This script disables DSC on Linux by stopping the DSC service.
# 

echo "Running Update"
exit 0