#!/bin/bash
# 
# This script disables DSC on Linux by stopping the DSC service.
# 

echo "Running Install"
exit 0