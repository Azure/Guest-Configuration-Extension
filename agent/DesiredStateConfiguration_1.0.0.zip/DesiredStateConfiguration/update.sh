#!/bin/bash
# 
# This script is used to update DSC on Linux.
# 
