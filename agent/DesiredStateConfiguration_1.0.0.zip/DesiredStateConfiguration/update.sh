#!/bin/bash
# 
# This script is used to update DSC on Linux.
# Expects one parameter specifying the path to the folder containing the
# install/uninstall scripts for the old DSC version.
#
# Return codes:
# 0 - Success
# 1 - Install of new DSC version failed, but successfully rolled back to the old version
# 2 - Install of new DSC version failed, and rollback to previous version failed
# 

OLD_VERSION_PATH=$1
NEW_VERSION_PATH="$PWD"

OLD_UNINSTALL_SCRIPT_PATH="$OLD_VERSION_PATH/uninstall.sh"
OLD_INSTALL_SCRIPT_PATH="$OLD_VERSION_PATH/install.sh"
OLD_ENABLE_SCRIPT_PATH="$OLD_VERSION_PATH/enable.sh"
NEW_INSTALL_SCRIPT_PATH="$NEW_VERSION_PATH/install.sh"

RETURN_CODE_SUCCESS=0
RETURN_CODE_ROLLBACK_SUCCESS=1
RETURN_CODE_ROLLBACK_FAIL=2

print_error() {
  echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@" >&2
}

# Uninstall old version
cd $OLD_VERSION_PATH
$OLD_UNINSTALL_SCRIPT_PATH
if [ $? -ne 0 ]; then
    echo "Uninstallation of old DSC version failed. This may cause problems in the installation of the new DSC version. Continuing with new DSC version install..."
fi

# Install new version
cd $NEW_VERSION_PATH
$NEW_INSTALL_SCRIPT_PATH

# Rollback to old version if install of new version fails
if [ $? -ne 0 ]; then
    cd $OLD_VERSION_PATH
    $OLD_INSTALL_SCRIPT_PATH
    if [ $? -ne 0 ]; then
        cd $NEW_VERSION_PATH
        print_error "Installation of new DSC version failed, and failed install on rollback to previous version."
        exit $RETURN_CODE_ROLLBACK_FAIL
    else
        $OLD_ENABLE_SCRIPT_PATH
        if [ $? -ne 0 ]; then
            cd $NEW_VERSION_PATH
            print_error "Installation of new DSC version failed, and failed enable on rollback to previous version."
            exit $RETURN_CODE_ROLLBACK_FAIL
        else
            cd $NEW_VERSION_PATH
            echo "Installation of new DSC version failed, but successfully rolled back to previous version."
            exit $RETURN_CODE_ROLLBACK_SUCCESS
        fi
    fi
else
    exit $RETURN_CODE_SUCCESS
fi
