#!/bin/bash
# 
# This script installs DSC on Linux and start the DSC service.
# 

DSC_HOME_PATH="$PWD"
DSC_EXE_PATH="$DSC_HOME_PATH/dsc_rest_server_main"
SERVICE_TEMP_FOLDER_PATH="$DSC_HOME_PATH/service_temp"

SERVICE_SCRIPTS_FOLDER_PATH="$DSC_HOME_PATH/service_scripts"
SERVICE_CONTROLLER_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/dsc_service_controller"
PID_FILE_PATH="$SERVICE_TEMP_FOLDER_PATH/dsc.pid"

DSC_SERVICE_NAME="dscd"

DSC_SYSTEMD_FILE_NAME="$DSC_SERVICE_NAME.systemd"
DSC_SYSTEMD_SOURCE_FILE_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/$DSC_SYSTEMD_FILE_NAME"
DSC_SYSTEMD_TEMP_FILE_PATH="$SERVICE_TEMP_FOLDER_PATH/$DSC_SYSTEMD_FILE_NAME"

DSC_UPSTART_FILE_NAME="$DSC_SERVICE_NAME.upstart"
DSC_UPSTART_SOURCE_FILE_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/$DSC_UPSTART_FILE_NAME"
DSC_UPSTART_TEMP_FILE_PATH="$SERVICE_TEMP_FOLDER_PATH/$DSC_UPSTART_FILE_NAME"

DSC_SYSV_FILE_NAME="$DSC_SERVICE_NAME.initd"
DSC_SYSV_SOURCE_FILE_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/$DSC_SYSV_FILE_NAME"
DSC_SYSV_TEMP_FILE_PATH="$SERVICE_TEMP_FOLDER_PATH/$DSC_SYSV_FILE_NAME"

SYSTEMD_UNIT_DIR=""

print_error() {
  echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@" >&2
}

check_result() {
    if [ $1 -ne 0 ]; then
        print_error $2
        exit $1
    fi
}

install_library() {
    if dpkg -l $1 >/dev/null 2>&1; then
        echo "$1 is already installed"
    else
        echo "Installing $1"
        sudo apt-get -y install $1
    fi

    check_result $? "Installation of library $1 failed"
}

install_dependencies() {
    install_library "libcurl3-gnutls"
    install_library "libcurl3"
}

resolve_systemd_paths() {
    local UNIT_DIR_LIST="/usr/lib/systemd/system /lib/systemd/system"

    if pidof systemd 1> /dev/null 2> /dev/null; then
        # Be sure systemctl lives where we expect it to
        if [ ! -f /bin/systemctl ]; then
            print_error "FATAL: Unable to locate systemctl program"
            exit 1
        fi

        # Find systemd unit directory
        for i in ${UNIT_DIR_LIST}; do
            if [ -d $i ]; then
                SYSTEMD_UNIT_DIR=${i}
                return 0
            fi
        done

        # Didn't find unit directory, that's fatal
        print_error "FATAL: Unable to resolve systemd unit directory"
        exit 1
    else
	    return 1
    fi
}

create_systemd_config_file() {
    # Remove any old temp systemd configuration file that may exist
    if [ -f $DSC_SYSTEMD_TEMP_FILE_PATH ]; then
        sudo rm -f $DSC_SYSTEMD_TEMP_FILE_PATH
    fi

    if [ ! -d $SERVICE_TEMP_FOLDER_PATH ]; then
        mkdir $SERVICE_TEMP_FOLDER_PATH
    fi

    # Replace the pid file and exe file paths in the systemd configuration file
    cat $DSC_SYSTEMD_SOURCE_FILE_PATH | sed "s@<PID_FILE_PATH>@$PID_FILE_PATH@g" | sed "s@<EXE_FILE_PATH>@$DSC_EXE_PATH@g" > $DSC_SYSTEMD_TEMP_FILE_PATH;

    # Set the new temp systemd configuration file to the correct permissions  
    chmod a+x $DSC_SYSTEMD_TEMP_FILE_PATH;
}

create_upstart_config_file() {
    # Remove any old temp upstart configuration file that may exist
    if [ -f $DSC_UPSTART_TEMP_FILE_PATH ]; then
        sudo rm -f $DSC_UPSTART_TEMP_FILE_PATH
    fi

    if [ ! -d $SERVICE_TEMP_FOLDER_PATH ]; then
        mkdir $SERVICE_TEMP_FOLDER_PATH
    fi

    # Replace the exe file path in the upstart configuration file
    cat $DSC_UPSTART_SOURCE_FILE_PATH | sed "s@<DSC_EXE_PATH>@$DSC_EXE_PATH@g" > $DSC_UPSTART_TEMP_FILE_PATH;

    # Set the new temp upstart configuration file to the correct permissions  
    chmod a+x $DSC_UPSTART_TEMP_FILE_PATH;
}

create_sysv_config_file() {
    # Remove any old temp sysv configuration file that may exist
    if [ -f $DSC_SYSV_TEMP_FILE_PATH ]; then
        sudo rm -f $DSC_SYSV_TEMP_FILE_PATH
    fi

    if [ ! -d $SERVICE_TEMP_FOLDER_PATH ]; then
        mkdir $SERVICE_TEMP_FOLDER_PATH
    fi

    # Replace the pid file and exe file paths in the sysv configuration file
    cat $DSC_SYSV_SOURCE_FILE_PATH | sed "s@<PID_FILE_PATH>@$PID_FILE_PATH@g" | sed "s@<DSC_EXE_PATH>@$DSC_EXE_PATH@g" > $DSC_SYSV_TEMP_FILE_PATH;

    # Set the new temp sysv configuration file to the correct permissions  
    chmod a+x $DSC_SYSV_TEMP_FILE_PATH;
}

install_dsc_service() {
    if [ -f $PID_FILE_PATH ]; then
        echo "DSC service is already running. Skipping service installation."
        return 0
    fi

    # If the marker file dsc_disable_service_control exists,
    # DSC will not be configured with service manager. This may be used in a container
    # environment, where service manager does not work reliably.
    if [ ! -f $SERVICE_SCRIPTS_FOLDER_PATH/dsc_disable_service_control ]; then
      # Set the DSC service controller to be executable
      chown root $SERVICE_CONTROLLER_PATH
      chmod 700 $SERVICE_CONTROLLER_PATH

      echo "Configuring DSC service ..."
      pidof systemd 1> /dev/null 2> /dev/null
      if [ $? -eq 0 ]; then
          # systemd
          echo "Found systemd service controller..."
          resolve_systemd_paths
          create_systemd_config_file
          cp $DSC_SYSTEMD_TEMP_FILE_PATH ${SYSTEMD_UNIT_DIR}/dscd.service
          /bin/systemctl daemon-reload
          /bin/systemctl enable dscd
      elif [ -x /sbin/initctl -a -f /etc/init/networking.conf ]; then
          # If we have /sbin/initctl, we have upstart.
          # Note that the upstart script requires networking,
          # so only use upstart if networking is controlled by upstart (not the case in RedHat 6)
          echo "Found upstart service controller with networking..."
          create_upstart_config_file
          cp $DSC_UPSTART_TEMP_FILE_PATH /etc/init/dscd.conf

          # initctl registers it with upstart
          initctl reload-configuration
      else
          echo "Found sysv service controller..."
          create_sysv_config_file
          cp $DSC_SYSV_TEMP_FILE_PATH /etc/init.d/dscd

          if [ -x /usr/sbin/update-rc.d ]; then
              update-rc.d dscd defaults > /dev/null
          elif [ -x /usr/lib/lsb/install_initd ]; then
              /usr/lib/lsb/install_initd /etc/init.d/dscd
          elif [ -x /sbin/chkconfig ]; then
              chkconfig --add dscd > /dev/null
          else
              print_error "Unrecognized service controller to configure DSC service"
              exit 1
          fi
      fi
    fi
}

install_dsc() {
    install_dependencies

    cp "$DSC_HOME_PATH/libmi.so" /usr/lib/
    check_result $? "Copying libmi to user library folder failed"

    chmod 700 ./consistency_invoker
    check_result $? "Setting permissions of consistency_invoker file failed"
    
    chmod 700 ./dsc_rest_server_main
    check_result $? "Setting permissions of dsc_rest_server_main file failed"

    chmod 700 ./*.sh
    check_result $? "Setting permissions of .sh files failed"

    install_dsc_service
}

install_inspec() {
    if dpkg -l inspec >/dev/null 2>&1; then
        echo "Inspec is already installed."
    else
        echo "Installing inspec..."

        # Only works with Ubuntu for now
        UBUNTU_VERSION=$(lsb_release -r -s)

        INSPEC_PACKAGE_NAME="inspec_2.2.61-1_amd64.deb"
        INSPEC_DOWNLOAD_URL="https://packages.chef.io/files/stable/inspec/2.2.61/ubuntu/$UBUNTU_VERSION/$INSPEC_PACKAGE_NAME"
        curl -O $INSPEC_DOWNLOAD_URL >/dev/null

        export DEBIAN_FRONTEND=noninteractive
        dpkg -i "$DSC_HOME_PATH/$INSPEC_PACKAGE_NAME"
        check_result $? "Installation of inspec failed"
    fi
}

install_inspec_resource_dependencies() {
    install_inspec

    mkdir -p /tmp/ChefInSpec
    check_result $? "Creation of ChefInSpec directory under tmp folder failed"
    
    sudo cp ./DSCOaasCert.crt /tmp/DSCOaasCert.crt
    check_result $? "Copying of DSC cert failed"
    sudo cp ./runinspec.sh /tmp/runinspec.sh
    check_result $? "Copying of runinspec script failed"
    sudo chmod 700 /tmp/runinspec.sh
    check_result $? "Setting permissions of runinspec script failed"
}

install_dsc
check_result $? "Installation of DSC failed"
install_inspec_resource_dependencies
