#!/bin/bash
# 
# This script is used to disable DSC on Linux.
# 
