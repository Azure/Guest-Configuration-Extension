#!/bin/bash
# 
# This script disables DSC on Linux by stopping the DSC service.
# 

DSC_HOME_PATH="$PWD"
SERVICE_SCRIPTS_FOLDER_PATH="$DSC_HOME_PATH/service_scripts"
SERVICE_CONTROLLER_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/dsc_service_controller"

CRON_FILE_PATH="/etc/cron.d/dsc_consistency"

print_error() {
  echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@" >&2
}

check_result() {
    if [ $1 -ne 0 ]; then
        print_error $2
        exit $1
    fi
}

stop_dsc_service() {
    $SERVICE_CONTROLLER_PATH stop
    check_result $? "Stopping the DSC service failed"
}

remove_dsc_cron_job() {
    if [ -f $CRON_FILE_PATH ]; then
        rm $CRON_FILE_PATH
        check_result $? "Removing the DSC cron job failed"
    fi
}

disable_dsc() {
    stop_dsc_service
    remove_dsc_cron_job
}

disable_dsc
