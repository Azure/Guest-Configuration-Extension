#!/bin/bash
# 
# This script enables DSC on Linux by starting the DSC service.
#

DSC_HOME_PATH="$PWD"
CONSISTENCY_INVOKER_PATH="$DSC_HOME_PATH/consistency_invoker"
SERVICE_SCRIPTS_FOLDER_PATH="$DSC_HOME_PATH/service_scripts"
SERVICE_CONTROLLER_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/dsc_service_controller"

CRON_FILE_PATH="/etc/cron.d/dsc_consistency"

print_error() {
  echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@" >&2
}

check_result() {
    if [ $1 -ne 0 ]; then
        print_error $2
        exit $1
    fi
}

start_dsc_service() {
    $SERVICE_CONTROLLER_PATH start
    check_result $? "Starting the DSC service failed"
}

# Creates a cron job to run the DSC consistency invoker every 5 mins
create_dsc_cron_job() {
    if [ ! -f $CRON_FILE_PATH ]; then
        echo "*/5 *   * * *   root    $CONSISTENCY_INVOKER_PATH" > $CRON_FILE_PATH
        check_result $? "Starting the DSC cron job failed"
    fi
}

run_consistency() {
    $CONSISTENCY_INVOKER_PATH
}

enable_dsc() {
    start_dsc_service
    create_dsc_cron_job
    run_consistency
}

enable_dsc
