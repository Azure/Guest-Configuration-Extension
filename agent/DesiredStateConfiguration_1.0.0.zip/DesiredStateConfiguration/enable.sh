#!/bin/bash
# 
# This script is used to install DSC on Linux, start the REST server,
# and trigger consistency runs every 5 minutes.
# 

INSTALL_PATH="$PWD"
CRON_FILE="/etc/cron.d/dsc_consistency"

STATUS_CODE=0


function install_inspec {
    if dpkg -l inspec >/dev/null 2>&1; then
        echo "inspec is already installed"
    else
        echo "Installing inspec"
        sudo apt-get -y install ruby ruby-dev gcc g++ make
        STATUS_CODE=$?
        check_result

        sudo gem install inspec --no-ri --no-rdoc
        STATUS_CODE=$?
        check_result
    fi
}

function install_library {
    if dpkg -l $1 >/dev/null 2>&1; then
        echo "$1 is already installed"
    else
        echo "Installing $1"
        sudo apt-get -y install $1
    fi
    STATUS_CODE=$?
    check_result
}

function install_dependencies {
    install_inspec

    install_library "libcurl3-gnutls"
    install_library "libcurl3"
    install_library "libcpprest"
    install_library "minizip"
    install_library "libboost-filesystem1.58.0"
}

function enable_dsc {
    sudo cp ./libmi.so /usr/lib/
    mkdir -p /tmp/ChefInSpec
    STATUS_CODE=$?
    check_result

    sudo cp ./DSCOaasCert.crt /tmp/DSCOaasCert.crt
    STATUS_CODE=$?
    check_result

    sudo cp ./runinspec.sh /tmp/runinspec.sh
    STATUS_CODE=$?
    check_result

    sudo chmod 755 /tmp/runinspec.sh
    STATUS_CODE=$?
    check_result

    sudo chmod 755 ./consistency_invoker
    STATUS_CODE=$?
    check_result
    
    sudo chmod 755 ./dsc_rest_server_main
    STATUS_CODE=$?
    check_result

    # create cron job to run <install path>/consistency_invoker every 5 mins
    if [ ! -f "$CRON_FILE" ]; then
        sudo bash -c "echo '*/5 *   * * *   root    $INSTALL_PATH/consistency_invoker' > $CRON_FILE"
        STATUS_CODE=$?
        check_result
    fi
}

function check_result {
    if [ $STATUS_CODE -ne 0 ]; then
        echo "Installation failed"
        exit $STATUS_CODE
    fi
}

install_dependencies
enable_dsc

# run rest server in background
$INSTALL_PATH/dsc_rest_server_main &
# run consistency
$INSTALL_PATH/consistency_invoker
