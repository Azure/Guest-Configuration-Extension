#!/bin/bash
# 
# This script is used to uninstall DSC on Linux.
# 
