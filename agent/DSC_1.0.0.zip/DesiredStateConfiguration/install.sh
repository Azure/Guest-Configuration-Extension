#!/bin/bash
# 
# This script installs DSC on Linux and start the DSC service.
# 

DSC_HOME_PATH="$PWD"
DSC_EXE_PATH="$DSC_HOME_PATH/dsc_rest_server_main"
SERVICE_TEMP_FOLDER_PATH="$DSC_HOME_PATH/service_temp"

SERVICE_SCRIPTS_FOLDER_PATH="$DSC_HOME_PATH/service_scripts"
SERVICE_CONTROLLER_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/dsc_service_controller"
PID_FILE_PATH="$SERVICE_TEMP_FOLDER_PATH/dsc.pid"

DSC_SERVICE_NAME="dscd"

DSC_SYSTEMD_FILE_NAME="$DSC_SERVICE_NAME.systemd"
DSC_SYSTEMD_SOURCE_FILE_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/$DSC_SYSTEMD_FILE_NAME"
DSC_SYSTEMD_TEMP_FILE_PATH="$SERVICE_TEMP_FOLDER_PATH/$DSC_SYSTEMD_FILE_NAME"

DSC_UPSTART_FILE_NAME="$DSC_SERVICE_NAME.upstart"
DSC_UPSTART_SOURCE_FILE_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/$DSC_UPSTART_FILE_NAME"
DSC_UPSTART_TEMP_FILE_PATH="$SERVICE_TEMP_FOLDER_PATH/$DSC_UPSTART_FILE_NAME"

DSC_SYSV_FILE_NAME="$DSC_SERVICE_NAME.initd"
DSC_SYSV_SOURCE_FILE_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/$DSC_SYSV_FILE_NAME"
DSC_SYSV_TEMP_FILE_PATH="$SERVICE_TEMP_FOLDER_PATH/$DSC_SYSV_FILE_NAME"

SYSTEMD_UNIT_DIR=""
LINUX_DISTRO=""

print_error() {
  echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@" >&2
}

check_result() {
    if [ $1 -ne 0 ]; then
        print_error $2
        exit $1
    fi
}

get_linux_distro() {
    VERSION_OUTPUT=$(cat /proc/version)

    if [[ $VERSION_OUTPUT = *"Ubuntu"* ]]; then
        LINUX_DISTRO="Ubuntu"
    elif [[ $VERSION_OUTPUT = *"Red Hat"* ]]; then
        LINUX_DISTRO="Red Hat"
    elif [[ $VERSION_OUTPUT = *"SUSE"* ]]; then
        LINUX_DISTRO="SUSE"
    elif [[ $VERSION_OUTPUT = *"CentOS"* ]]; then
        LINUX_DISTRO="CentOS"
    elif [[ $VERSION_OUTPUT = *"Debian"* ]]; then
        LINUX_DISTRO="Debian"
    fi
}

install_curl_dependecy() {
    get_linux_distro

    case "$LINUX_DISTRO" in

    "Ubuntu")  echo "Installing library libcurl4-openssl-dev on Ubuntu"
        if dpkg -l libcurl4-openssl-dev >/dev/null 2>&1; then
            echo "libcurl4-openssl-dev is already installed"
        else
            echo "Installing libcurl4-openssl-dev"
            apt-get -y install libcurl4-openssl-dev
            check_result $? "Installation of library libcurl4-openssl-dev failed on Ubuntu"
        fi
        ;;
    "Red Hat")  echo  "Installing library libcurl-devel on Red Hat"
        if yum list installed libcurl-devel >/dev/null 2>&1; then
            echo "libcurl-devel is already installed"
        else
            echo "Installing libcurl-devel"
            yum -y install libcurl-devel
            check_result $? "Installation of library libcurl-devel failed on Red Hat"
        fi
        ;;
    "SUSE")  echo  "Installing library libcurl-devel on SUSE"
        if zypper search libcurl-devel >/dev/null 2>&1; then
            echo "libcurl-devel is already installed"
        else
            echo "Installing libcurl-devel"
            zypper -n install libcurl-devel
            check_result $? "Installation of library libcurl-devel failed on SUSE"
        fi
        ;;
    "CentOS")  echo  "Installing library libcurl-devel on CentOS"
        if yum list installed libcurl-devel >/dev/null 2>&1; then
            echo "libcurl-devel is already installed"
        else
            echo "Installing libcurl-devel"
            yum -y install libcurl-devel
            check_result $? "Installation of library libcurl-devel failed on CentOS"
        fi
        ;;
    "Debian") echo  "Installing library libcurl4-openssl-dev on Debian"
        if dpkg -l libcurl4-openssl-dev >/dev/null 2>&1; then
            echo "libcurl4-openssl-dev is already installed"
        else
            echo "Installing libcurl4-openssl-dev"
            sudo apt-get -y install libcurl4-openssl-dev
            check_result $? "Installation of library libcurl4-openssl-dev failed on Debian"
        fi
        ;;
    *) echo "Could not install curl dev library for linux distro '$LINUX_DISTRO'"
        ;;
    esac
}

install_dependencies() {
    install_curl_dependecy
}

resolve_systemd_paths() {
    local UNIT_DIR_LIST="/usr/lib/systemd/system /lib/systemd/system"

    if pidof systemd 1> /dev/null 2> /dev/null; then
        # Be sure systemctl lives where we expect it to
        if [ ! -f /bin/systemctl ]; then
            print_error "FATAL: Unable to locate systemctl program"
            exit 1
        fi

        # Find systemd unit directory
        for i in ${UNIT_DIR_LIST}; do
            if [ -d $i ]; then
                SYSTEMD_UNIT_DIR=${i}
                return 0
            fi
        done

        # Didn't find unit directory, that's fatal
        print_error "FATAL: Unable to resolve systemd unit directory"
        exit 1
    else
	    return 1
    fi
}

create_systemd_config_file() {
    # Remove any old temp systemd configuration file that may exist
    if [ -f $DSC_SYSTEMD_TEMP_FILE_PATH ]; then
        sudo rm -f $DSC_SYSTEMD_TEMP_FILE_PATH
    fi

    if [ ! -d $SERVICE_TEMP_FOLDER_PATH ]; then
        mkdir $SERVICE_TEMP_FOLDER_PATH
    fi

    # Replace the pid file and exe file paths in the systemd configuration file
    cat $DSC_SYSTEMD_SOURCE_FILE_PATH | sed "s@<PID_FILE_PATH>@$PID_FILE_PATH@g" | sed "s@<EXE_FILE_PATH>@$DSC_EXE_PATH@g" > $DSC_SYSTEMD_TEMP_FILE_PATH;

    # Set the new temp systemd configuration file to the correct permissions  
    chmod a+x $DSC_SYSTEMD_TEMP_FILE_PATH;
}

create_upstart_config_file() {
    # Remove any old temp upstart configuration file that may exist
    if [ -f $DSC_UPSTART_TEMP_FILE_PATH ]; then
        sudo rm -f $DSC_UPSTART_TEMP_FILE_PATH
    fi

    if [ ! -d $SERVICE_TEMP_FOLDER_PATH ]; then
        mkdir $SERVICE_TEMP_FOLDER_PATH
    fi

    # Replace the exe file path in the upstart configuration file
    cat $DSC_UPSTART_SOURCE_FILE_PATH | sed "s@<DSC_EXE_PATH>@$DSC_EXE_PATH@g" > $DSC_UPSTART_TEMP_FILE_PATH;

    # Set the new temp upstart configuration file to the correct permissions  
    chmod a+x $DSC_UPSTART_TEMP_FILE_PATH;
}

create_sysv_config_file() {
    # Remove any old temp sysv configuration file that may exist
    if [ -f $DSC_SYSV_TEMP_FILE_PATH ]; then
        sudo rm -f $DSC_SYSV_TEMP_FILE_PATH
    fi

    if [ ! -d $SERVICE_TEMP_FOLDER_PATH ]; then
        mkdir $SERVICE_TEMP_FOLDER_PATH
    fi

    # Replace the pid file and exe file paths in the sysv configuration file
    cat $DSC_SYSV_SOURCE_FILE_PATH | sed "s@<PID_FILE_PATH>@$PID_FILE_PATH@g" | sed "s@<DSC_EXE_PATH>@$DSC_EXE_PATH@g" > $DSC_SYSV_TEMP_FILE_PATH;

    # Set the new temp sysv configuration file to the correct permissions  
    chmod a+x $DSC_SYSV_TEMP_FILE_PATH;
}

install_dsc_service() {
    # Set the DSC service controller to be executable
    chown root $SERVICE_CONTROLLER_PATH
    chmod 700 $SERVICE_CONTROLLER_PATH

    echo "Configuring DSC service ..."
    pidof systemd 1> /dev/null 2> /dev/null
    if [ $? -eq 0 ]; then
        # systemd
        echo "Found systemd service controller..."
        resolve_systemd_paths
        create_systemd_config_file
        cp $DSC_SYSTEMD_TEMP_FILE_PATH ${SYSTEMD_UNIT_DIR}/dscd.service
        /bin/systemctl daemon-reload
        /bin/systemctl enable dscd 2>&1
    elif [ -x /sbin/initctl -a -f /etc/init/networking.conf ]; then
        # If we have /sbin/initctl, we have upstart.
        # Note that the upstart script requires networking,
        # so only use upstart if networking is controlled by upstart (not the case in RedHat 6)
        echo "Found upstart service controller with networking..."
        create_upstart_config_file
        cp $DSC_UPSTART_TEMP_FILE_PATH /etc/init/dscd.conf

        # initctl registers it with upstart
        initctl reload-configuration
    else
        echo "Found sysv service controller..."
        create_sysv_config_file
        cp $DSC_SYSV_TEMP_FILE_PATH /etc/init.d/dscd

        if [ -x /usr/sbin/update-rc.d ]; then
            update-rc.d dscd defaults > /dev/null
        elif [ -x /usr/lib/lsb/install_initd ]; then
            /usr/lib/lsb/install_initd /etc/init.d/dscd
        elif [ -x /sbin/chkconfig ]; then
            chkconfig --add dscd > /dev/null
        else
            print_error "Unrecognized service controller to configure DSC service"
            exit 1
        fi
    fi
}

install_dsc() {
    install_dependencies

    cp "$DSC_HOME_PATH/libmi.so" /usr/lib/
    check_result $? "Copying libmi to user library folder failed"

    chmod 700 ./consistency_invoker
    check_result $? "Setting permissions of consistency_invoker file failed"
    
    chmod 700 ./dsc_rest_server_main
    check_result $? "Setting permissions of dsc_rest_server_main file failed"

    chmod 700 ./*.sh
    check_result $? "Setting permissions of .sh files failed"

    install_dsc_service
}

install_inspec() {
    get_linux_distro

    case "$LINUX_DISTRO" in
    "Ubuntu")
        if dpkg -l inspec >/dev/null 2>&1; then
            echo "inspec is already installed on Ubuntu"
        else
            echo "Installing inspec on Ubuntu"
            UBUNTU_VERSION=$(lsb_release -r -s)

            INSPEC_PACKAGE_NAME="inspec_2.2.61-1_amd64.deb"
            INSPEC_DOWNLOAD_URL="https://packages.chef.io/files/stable/inspec/2.2.61/ubuntu/$UBUNTU_VERSION/$INSPEC_PACKAGE_NAME"
            curl -s -O $INSPEC_DOWNLOAD_URL >/dev/null

            export DEBIAN_FRONTEND=noninteractive
            dpkg -i "$DSC_HOME_PATH/$INSPEC_PACKAGE_NAME"
            check_result $? "Installation of inspec failed on Ubuntu"
        fi
        ;;
    "Red Hat")
        if rpm -qa | grep inspec >/dev/null 2>&1; then
            echo "inspec is already installed on Red Hat"
        else
            echo "Installing inspec on Red Hat"
            INSPEC_PACKAGE_NAME="inspec-2.2.61-1.el7.x86_64.rpm"
            INSPEC_DOWNLOAD_URL="https://packages.chef.io/files/stable/inspec/2.2.61/el/7/$INSPEC_PACKAGE_NAME"
            curl -s -O $INSPEC_DOWNLOAD_URL >/dev/null

            rpm -i "$DSC_HOME_PATH/$INSPEC_PACKAGE_NAME" --nosignature
            check_result $? "Installation of inspec failed on Red Hat"
        fi
        ;;
    "SUSE")
        if rpm -qa | grep inspec >/dev/null 2>&1; then
            echo "inspec is already installed on SUSE"
        else
            echo "Installing inspec on SUSE"
            INSPEC_PACKAGE_NAME="inspec-2.2.61-1.sles12.x86_64.rpm"
            INSPEC_DOWNLOAD_URL="https://packages.chef.io/files/stable/inspec/2.2.61/sles/12/$INSPEC_PACKAGE_NAME"
            curl -s -O $INSPEC_DOWNLOAD_URL >/dev/null

            rpm -i "$DSC_HOME_PATH/$INSPEC_PACKAGE_NAME" --nosignature
            check_result $? "Installation of inspec failed on SUSE"
        fi
        ;;
    "CentOS")
        if rpm -qa | grep inspec >/dev/null 2>&1; then
            echo "inspec is already installed on CentOS"
        else
            echo "Installing inspec on CentOS"
            INSPEC_PACKAGE_NAME="inspec-2.2.61-1.el7.x86_64.rpm"
            INSPEC_DOWNLOAD_URL="https://packages.chef.io/files/stable/inspec/2.2.61/el/7/$INSPEC_PACKAGE_NAME"
            curl -s -O $INSPEC_DOWNLOAD_URL >/dev/null

            rpm -i "$DSC_HOME_PATH/$INSPEC_PACKAGE_NAME" --nosignature
            check_result $? "Installation of inspec failed on CentOS"
        fi
        ;;
    "Debian")
        if dpkg -l libcurl4-openssl-dev >/dev/null 2>&1; then
            echo "inspec is already installed on Debian"
        else
            echo "Installing inspec on Debian"
            INSPEC_PACKAGE_NAME="inspec_2.2.61-1_amd64.deb"
            INSPEC_DOWNLOAD_URL="https://packages.chef.io/files/stable/inspec/2.2.61/ubuntu/14.04/$INSPEC_PACKAGE_NAME"
            curl -s -O $INSPEC_DOWNLOAD_URL >/dev/null

            export DEBIAN_FRONTEND=noninteractive
            dpkg -i "$DSC_HOME_PATH/$INSPEC_PACKAGE_NAME"
            check_result $? "Installation of library libcurl4-openssl-dev failed on Debian"
        fi
        ;;
    *) echo "Could not install inspec for linux distro '$LINUX_DISTRO'"
        ;;
    esac
}

install_inspec_resource_dependencies() {
    install_inspec
    sudo cp ./DSCOaasCert.crt /tmp/DSCOaasCert.crt
    check_result $? "Copying of DSC cert failed"
}

install_dsc
check_result $? "Installation of DSC failed"
install_inspec_resource_dependencies
