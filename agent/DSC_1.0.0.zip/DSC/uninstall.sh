#!/bin/bash
# 
# This script uninstalls DSC on Linux.
# 

DSC_HOME_PATH="$PWD"
SERVICE_TEMP_FOLDER_PATH="$DSC_HOME_PATH/service_temp"

SERVICE_SCRIPTS_FOLDER_PATH="$DSC_HOME_PATH/service_scripts"
SERVICE_CONTROLLER_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/dsc_service_controller"

DSC_SERVICE_NAME="dscd"

SYSTEMD_UNIT_DIR=""

print_error() {
  echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@" >&2
}

check_result() {
    if [ $1 -ne 0 ]; then
        print_error $2
        exit $1
    fi
}

resolve_systemd_paths() {
    local UNIT_DIR_LIST="/usr/lib/systemd/system /lib/systemd/system"

    if pidof systemd 1> /dev/null 2> /dev/null; then
        # Be sure systemctl lives where we expect it to
        if [ ! -f /bin/systemctl ]; then
            print_error "FATAL: Unable to locate systemctl program"
            exit 1
        fi

        # Find systemd unit directory
        for i in ${UNIT_DIR_LIST}; do
            if [ -d $i ]; then
                SYSTEMD_UNIT_DIR=${i}
                return 0
            fi
        done

        # Didn't find unit directory, that's fatal
        print_error "FATAL: Unable to resolve systemd unit directory"
        exit 1
    else
	    return 1
    fi
}

remove_service() {
    SERVICE=$1
    if [ -z "$SERVICE" ]; then
        echo "FATAL: remove_service requires parameter (service name)" 1>&2
        exit 1
    fi

    # Stop the service in case it's running
    $SERVICE_CONTROLLER_PATH stop

    # Registered as a systemd service?
    #
    # Note: We've never deployed systemd unit files automatically in the %Files
    # section. Thus, for systemd services, it's safe to remove the file.

    if [ -f ${SYSTEMD_UNIT_DIR}/${SERVICE}.service ]; then
        echo "Unconfiguring ${SERVICE} (systemd) service ..."
        /bin/systemctl disable ${SERVICE}
        rm -f ${SYSTEMD_UNIT_DIR}/${SERVICE}.service
        /bin/systemctl daemon-reload
    fi

    if [ -f /etc/init/${SERVICE}.conf ]; then
        echo "Unconfiguring ${SERVICE} (upstart) service ..."
        rm -f /usr/init/${SERVICE}.conf
        initctl reload-configuration
    fi

    if [ -f /etc/init.d/${SERVICE} ]; then
        echo "Unconfiguring ${SERVICE} service ..."
        if [ -f /usr/sbin/update-rc.d ]; then
            /usr/sbin/update-rc.d -f ${SERVICE} remove
        elif [ -x /usr/lib/lsb/remove_initd ]; then
            /usr/lib/lsb/remove_initd /etc/init.d/${SERVICE}
        elif [ -x /sbin/chkconfig ]; then
            chkconfig --del ${SERVICE} > /dev/null
        else
            echo "Unrecognized service controller to unregister ${SERVICE} service."
            exit 1
        fi
    fi

    return 0
}

remove_dsc_service() {
    remove_service $DSC_SERVICE_NAME
    [ -f /etc/init.d/$DSC_SERVICE_NAME ] && rm /etc/init.d/$DSC_SERVICE_NAME
    [ -f /etc/init/$DSC_SERVICE_NAME.conf ] && rm /etc/init/$DSC_SERVICE_NAME.conf
    return 0
}

remove_dsc_service
