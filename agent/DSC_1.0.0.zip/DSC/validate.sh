#!/bin/bash
# 
# This script installs DSC on Linux and start the DSC service.
# 

TIMEOUT=$1
DSC_HOME_PATH="$PWD"

print_error() {
  echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@" >&2
}

for file in $DSC_HOME_PATH/../Logs/dsc-*.log; do
  echo "$file"
  end=$(($SECONDS+$TIMEOUT))
  while [ $SECONDS -lt $end ]; do
    if grep -q "Start logging MI instance Get-TargetResource Posted Instance" $file && grep -q "Start logging MI instance Test-TargetResource Posted Instance" $file && grep -q "Sent assignment report for job" $file; then
      echo "InGuest Agent successfully process the policy and sent the report."
      exit 0
    else
      sleep 2
    fi
  done
  echo "InGuest Agent failed to process the policy. Error:"
  print_error $(grep "ERROR" $file)
  exit 1
done
