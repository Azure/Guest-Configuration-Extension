#!/bin/bash
# 
# This script installs DSC on Linux and starts the DSC service.
# 

DSC_HOME_PATH="$PWD"
DSC_EXE_PATH="$DSC_HOME_PATH/dsc_linux_service"
DSC_SERVER_SOCKET_PATH="$DSC_HOME_PATH/sockets"
SERVICE_TEMP_FOLDER_PATH="$DSC_HOME_PATH/service_temp"

SERVICE_SCRIPTS_FOLDER_PATH="$DSC_HOME_PATH/service_scripts"
SERVICE_CONTROLLER_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/dsc_service_controller"

DSC_SERVICE_NAME="dscd"

DSC_SYSTEMD_FILE_NAME="$DSC_SERVICE_NAME.systemd"
DSC_SYSTEMD_SOURCE_FILE_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/$DSC_SYSTEMD_FILE_NAME"
DSC_SYSTEMD_TEMP_FILE_PATH="$SERVICE_TEMP_FOLDER_PATH/$DSC_SYSTEMD_FILE_NAME"

DSC_UPSTART_FILE_NAME="$DSC_SERVICE_NAME.upstart"
DSC_UPSTART_SOURCE_FILE_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/$DSC_UPSTART_FILE_NAME"
DSC_UPSTART_TEMP_FILE_PATH="$SERVICE_TEMP_FOLDER_PATH/$DSC_UPSTART_FILE_NAME"

SYSTEMD_UNIT_DIR=""
SYSTEM_SERVICE_CONTROLLER=""

LINUX_DISTRO=""

print_error() {
  echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@" >&2
}

check_result() {
    if [ $1 -ne 0 ]; then
        print_error $2
        exit $1
    fi
}

get_linux_distro() {
    if [ ! -z $LINUX_DISTRO ]; then
        return
    fi

    VERSION_OUTPUT=$(cat /proc/version)

    if [[ $VERSION_OUTPUT = *"Ubuntu"* ]]; then
        LINUX_DISTRO="Ubuntu"
    elif [[ $VERSION_OUTPUT = *"Red Hat"* ]]; then
        LINUX_DISTRO="Red Hat"
    elif [[ $VERSION_OUTPUT = *"SUSE"* ]]; then
        LINUX_DISTRO="SUSE"
    elif [[ $VERSION_OUTPUT = *"CentOS"* ]]; then
        LINUX_DISTRO="CentOS"
    elif [[ $VERSION_OUTPUT = *"Debian"* ]]; then
        LINUX_DISTRO="Debian"
    else
        print_error "Unexpected Linux distribution. Expected Linux distributions include only Ubuntu, Red Hat, SUSE, CentOS, and Debian."
        exit 1
    fi

    echo "Linux distribution is $LINUX_DISTRO."
}

get_system_service_controller() {
    if [ ! -z $SYSTEM_SERVICE_CONTROLLER ]; then
        return
    fi

    COMM_OUTPUT=$(cat /proc/1/comm)

    if [[ $COMM_OUTPUT = *"systemd"* ]]; then
        SYSTEM_SERVICE_CONTROLLER="systemd"
    elif [[ $COMM_OUTPUT = *"init"* ]]; then
        SYSTEM_SERVICE_CONTROLLER="upstart"
    else
        print_error "Unexpected system service controller. Expected system service controllers are systemd and upstart."
        exit 1
    fi

    echo "Service controller is $SYSTEM_SERVICE_CONTROLLER."
}

resolve_systemd_paths() {
    local UNIT_DIR_LIST="/usr/lib/systemd/system /lib/systemd/system"

    # Be sure systemctl lives where we expect it to
    if [ ! -f /bin/systemctl ]; then
        print_error "FATAL: Unable to locate systemctl program"
        exit 1
    fi

    # Find systemd unit directory
    for i in ${UNIT_DIR_LIST}; do
        if [ -d $i ]; then
            SYSTEMD_UNIT_DIR=${i}
            return 0
        fi
    done

    # Didn't find unit directory, that's fatal
    print_error "FATAL: Unable to resolve systemd unit directory"
    exit 1
}

create_systemd_config_file() {
    # Remove any old temp systemd configuration file that may exist
    if [ -f $DSC_SYSTEMD_TEMP_FILE_PATH ]; then
        sudo rm -f $DSC_SYSTEMD_TEMP_FILE_PATH
    fi

    if [ ! -d $SERVICE_TEMP_FOLDER_PATH ]; then
        mkdir $SERVICE_TEMP_FOLDER_PATH
    fi

    # Replace the pid file and exe file paths in the systemd configuration file
    cat $DSC_SYSTEMD_SOURCE_FILE_PATH | sed "s@<EXE_FILE_PATH>@$DSC_EXE_PATH@g" > $DSC_SYSTEMD_TEMP_FILE_PATH;

    # Set the new temp systemd configuration file to the correct permissions  
    chmod 644 $DSC_SYSTEMD_TEMP_FILE_PATH;
}

install_systemd_service() {
    echo "Found systemd service controller..."
    resolve_systemd_paths
    create_systemd_config_file
    cp -f $DSC_SYSTEMD_TEMP_FILE_PATH ${SYSTEMD_UNIT_DIR}/dscd.service
    chmod 644 ${SYSTEMD_UNIT_DIR}/dscd.service
    /bin/systemctl daemon-reload
    /bin/systemctl enable dscd 2>&1
    echo "Service configured through systemd service controller."
}

create_upstart_config_file() {
    # Remove any old temp upstart configuration file that may exist
    if [ -f $DSC_UPSTART_TEMP_FILE_PATH ]; then
        sudo rm -f $DSC_UPSTART_TEMP_FILE_PATH
    fi

    if [ ! -d $SERVICE_TEMP_FOLDER_PATH ]; then
        mkdir $SERVICE_TEMP_FOLDER_PATH
    fi

    # Replace the exe file path in the upstart configuration file
    cat $DSC_UPSTART_SOURCE_FILE_PATH | sed "s@<DSC_EXE_PATH>@$DSC_EXE_PATH@g" > $DSC_UPSTART_TEMP_FILE_PATH;

    # Set the new temp upstart configuration file to the correct permissions  
    chmod 644 $DSC_UPSTART_TEMP_FILE_PATH;
}

install_upstart_service() {
    if [ -x /sbin/initctl -a -f /etc/init/networking.conf ]; then
        # If we have /sbin/initctl, we have upstart.
        # Note that the upstart script requires networking,
        # so only use upstart if networking is controlled by upstart (not the case in RedHat 6)
        echo "Found upstart service controller with networking..."
        create_upstart_config_file
        cp -f $DSC_UPSTART_TEMP_FILE_PATH /etc/init/dscd.conf
        chmod 644 /etc/init/dscd.conf
        # initctl registers it with upstart
        initctl reload-configuration
        echo "Service configured through upstart service controller."
    else
        print_error "Upstart service controller does not have control of the networking service."
        exit 1
    fi
}

install_dsc_service() {
    # Set the DSC service controller to be executable
    chown root $SERVICE_CONTROLLER_PATH
    chmod 700 $SERVICE_CONTROLLER_PATH
    
    $SERVICE_CONTROLLER_PATH stop

    echo "Configuring DSC service ..."
    pidof systemd 1> /dev/null 2> /dev/null
    if [ $? -eq 0 ]; then
        install_systemd_service
    else
        get_system_service_controller
        case "$SYSTEM_SERVICE_CONTROLLER" in
        "systemd")
            install_systemd_service
            ;;
        "upstart")
            install_upstart_service
            ;;
        *) echo "Unrecognized system service controller to configure DSC service."
            exit 1
            ;;
        esac
    fi
}

install_dsc() {
    chown root $DSC_EXE_PATH
    check_result $? "Setting owner of dsc_linux_service file failed"

    chmod 700 $DSC_EXE_PATH
    check_result $? "Setting permissions of dsc_linux_service file failed"

    chown root $DSC_HOME_PATH/*.sh
    check_result $? "Setting owner of .sh files failed"

    chmod 700 $DSC_HOME_PATH/*.sh
    check_result $? "Setting permissions of .sh files failed"

    mkdir -p $DSC_SERVER_SOCKET_PATH
    check_result $? "Creating sockets directory failed"
    chmod 700 $DSC_SERVER_SOCKET_PATH
    check_result $? "Setting permissions of sockets directory failed"
    chown root $DSC_SERVER_SOCKET_PATH
    check_result $? "Changing ownership of sockets directory failed"

    install_dsc_service
}

install_curl_dependency() {
    get_linux_distro

    case "$LINUX_DISTRO" in

    "Ubuntu")
        echo "Checking for package 'curl'..."
        if [ $(dpkg-query -W -f='${Status}' curl 2>/dev/null | grep -c "ok installed") -eq 0 ]; then
            echo "Installing package 'curl'..."
            export DEBIAN_FRONTEND=noninteractive
            apt -yq install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        else
            echo "Package 'curl' is already installed."
        fi
        ;;
    "Red Hat")
        echo "Checking for package 'curl'..."
        if yum list installed curl >/dev/null 2>&1; then
            echo "Package 'curl' is already installed."
        else
            echo "Installing package 'curl'..."
            yum -y install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        fi
        ;;
    "SUSE")
        echo "Checking for package 'curl'..."
        if zypper search curl >/dev/null 2>&1; then
            echo "Package 'curl' is already installed."
        else
            echo "Installing package 'curl'..."
            zypper -n install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        fi
        ;;
    "CentOS")
        echo "Checking for package 'curl'..."
        if yum list installed curl >/dev/null 2>&1; then
            echo "Package 'curl' is already installed."
        else
            echo "Installing package 'curl'..."
            yum -y install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        fi
        ;;
    "Debian")
        echo "Checking for package 'curl'..."
        if [ $(dpkg-query -W -f='${Status}' curl 2>/dev/null | grep -c "ok installed") -eq 0 ]; then
            echo "Installing package 'curl'..."
            export DEBIAN_FRONTEND=noninteractive
            apt -yq install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        else
            echo "Package 'curl' is already installed."
        fi
        ;;
    *) echo "Could not install curl dependency packages for unexpected Linux distribution '$LINUX_DISTRO'."
        exit 1 
        ;;
    esac
}

install_curl_dependency
check_result $? "Installation of curl failed"
install_dsc
check_result $? "Installation of DSC service failed"
