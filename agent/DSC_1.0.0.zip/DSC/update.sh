#!/bin/bash
# 
# This script is used to update DSC on Linux.
# Nothing needs to be migrated at the moment.
# 

find /var/lib/waagent/ -name dsc.config -exec cp {} . \; >/dev/null 2>&1

exit 0
