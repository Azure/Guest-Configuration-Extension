#!/bin/bash
# 
# This script is used to update DSC on Linux.
# Nothing needs to be migrated at the moment.
# 

return 0
