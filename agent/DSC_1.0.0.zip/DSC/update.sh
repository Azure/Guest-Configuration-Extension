#!/bin/bash
# 
# This script is used to update DSC on Linux.
# Expects one parameter specifying the path to the folder containing the
# uninstall script for the old DSC version.
#
# Return codes:
# 0 - Success
# 1 - Fail
# 

OLD_VERSION_PATH=$1
NEW_VERSION_PATH="$PWD"

OLD_UNINSTALL_SCRIPT_PATH="$OLD_VERSION_PATH/uninstall.sh"
NEW_INSTALL_SCRIPT_PATH="$NEW_VERSION_PATH/install.sh"
NEW_ENABLE_SCRIPT_PATH="$NEW_VERSION_PATH/enable.sh"

RETURN_CODE_SUCCESS=0
RETURN_CODE_FAIL=1

print_error() {
  echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@" >&2
}

# Uninstall old version
cd $OLD_VERSION_PATH
$OLD_UNINSTALL_SCRIPT_PATH
if [ $? -ne 0 ]; then
    print_error "Uninstallation of old DSC version failed. This may cause problems in the installation of the new DSC version. Continuing with new DSC version install..."
fi

# Install new version
cd $NEW_VERSION_PATH
$NEW_INSTALL_SCRIPT_PATH

if [ $? -ne 0 ]; then
    print_error "Installation of new DSC version failed."
    exit $RETURN_CODE_FAIL
else
    # Enable new version
    $NEW_ENABLE_SCRIPT_PATH
    if [ $? -ne 0 ]; then
        print_error "Enable of new DSC version failed."
        exit $RETURN_CODE_FAIL
    else
        exit $RETURN_CODE_SUCCESS
    fi
fi
