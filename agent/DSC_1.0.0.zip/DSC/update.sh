#!/bin/bash
# 
# This script is used to update DSC on Linux.
# Nothing needs to be migrated at the moment.
# 

# Create dsc config directory
mkdir /var/lib/GuestConfig/dsc -p

# create update flag
touch /var/lib/GuestConfig/updateDsc

# Migrate dsc.config file from old extension
find /var/lib/waagent/ -name dsc.config -exec cp {} /var/lib/GuestConfig/dsc \;

exit 0
