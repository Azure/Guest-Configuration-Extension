﻿###########################################################
#
#  'ServiceHelper' module
#
###########################################################

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$global:GCServiceName = "GCService"
$script:GCServiceBinaryName  = "gc_service.exe"
$script:GCServiceDisplayName = "Guest Configuration Service" 
$script:GCServiceDescription = "This service monitors desired state of the machine."

$global:GCArcServiceName = "GCArcService"
$script:GCArcServiceBinaryName  = "gc_arc_service.exe"
$script:GCArcServiceDisplayName = "Guest Configuration Arc Service" 
$script:GCArcServiceDescription = "This service monitors desired state of the machine."

$global:ExtServiceName = "ExtensionService"
$script:ExtServiceBinaryName  = "gc_extension_service.exe"
$script:ExtDisplayName = "Guest Configuration Extension service"
$script:ExtDescription = "The service installs the requested extensions"

$script:GCInstallPath = "$PSScriptRoot\..\..\.."
$script:GCBinariesFolderName = "GC"
$script:MigratedDataFolderName = "MigratedData"
$script:GCBinariesPath = Join-Path $script:GCInstallPath $script:GCBinariesFolderName

<#
    .SYNOPSIS
        Install GC Service. By default it calculates the GC Service Binary Path based on this GC Install Module location. 
    
    .Example
        Install-ServiceInternal
#>
Function Install-ServiceInternal {
    [CmdletBinding()]
    Param(
        [Parameter()]
        [string]
        $ServiceType = "GC"
    )

    Write-Verbose -Message "In Install-ServiceInternal"

    if ($ServiceType -eq "GC" -and (CheckServiceExists($global:GCServiceName)))
    {
        Write-Error "GC service already exists, can not install new service"
    }
    elseif ($ServiceType -eq "Extension" -and (CheckServiceExists($global:ExtServiceName)))
    {
        Write-Error "Extension service already exists, can not install new service"
    }
    elseif ($ServiceType -eq "GCArc" -and (CheckServiceExists($global:GCArcServiceName)))
    {
        Write-Error "GC Arc service already exists, can not install new service"
    }
    else
    {
        # Default values for GC Azure Service
        $serviceName = $global:GCServiceName
        $serviceBinaryName = $script:GCServiceBinaryName
        $displayName = $script:GCServiceDisplayName
        $description = $script:GCServiceDescription

        if ($ServiceType -eq "Extension")
        {
            $serviceName = $global:ExtServiceName
            $serviceBinaryName = $script:ExtServiceBinaryName
            $displayName = $script:ExtDisplayName
            $description = $script:ExtDescription
        }
        elseif ($ServiceType -eq "GCArc")
        {
            $serviceName = $global:GCArcServiceName
            $serviceBinaryName = $script:GCArcServiceBinaryName
            $displayName = $script:GCArcServiceDisplayName
            $description = $script:GCArcServiceDescription
        }

        $serviceBinaryPath = Join-Path $script:GCBinariesPath $serviceBinaryName
        $absolutePath = [System.IO.Path]::GetFullPath($serviceBinaryPath)
        Write-Verbose -Message "GC Service binary path : $absolutePath."

        $serviceApplication = Get-Command -Name $absolutePath -TotalCount 1

        if ($serviceApplication.CommandType -ne "Application")
        {
            Write-Error "Service binary type is not as expected" 
        }

        $servicePathWithQuotes = '"{0}"' -f $absolutePath
        $serviceBinaryPathCommand = $servicePathWithQuotes + " -k netsvcs"

        New-Service -Name $serviceName -BinaryPathName $serviceBinaryPathCommand -DisplayName $displayName -Description $description -StartupType Automatic

        $command = "sc.exe config $ServiceName start= delayed-auto"
        $Output = Invoke-Expression -Command $Command -ErrorAction Stop
        if ($LASTEXITCODE -ne 0)
        {
            Write-Warning "Failed to set $ServiceName to delayed start. More details: $Output"
        } 
        else
        {
            Write-Verbose "Successfully changed $ServiceName service to delayed start"
        }

        # For windows 2008 R2 + sp1 start-process with -Wait parameter does not work. Hence sleep for 10 sec instead.
        $osVersion=[Environment]::OSVersion.Version
        if (($osVersion.Major -eq 6) -and ($osVersion.Minor -eq 1) -and ($osVersion.Build -le 7601))
        {
            # configure recovery of the service during failure.
            $configureProcess = Start-Process sc.exe -ArgumentList "failure $serviceName reset= 30 actions= restart/10000/restart/20000/restart/30000" -PassThru
            Start-Sleep -Seconds 10
        }
        else
        {
            # configure recovery of the service during failure.
            $configureProcess = Start-Process sc.exe -ArgumentList "failure $serviceName reset=30 actions=restart/10000/restart/20000/restart/30000" -PassThru -Wait
        }

        if ($null -eq $configureProcess)
        {
            Write-Error "Failed to start sc.exe process to configure $serviceName service."
        }

        # on 2008R2 ExitCode is not set.
        if (($configureProcess.ExitCode -ne 0) -and ($null -ne $configureProcess.ExitCode))
        {
            Write-Warning "configuring service recovery options failed with exit-code:- $($configureProcess.ExitCode)"
        }
        Write-Verbose -Message "Successfully Installed new $serviceName."
    }

    Write-Verbose -Message "Validating $serviceName Properties."
   
    # Validate service Properties as returend by Get-Service.
    $serviceObject = Get-Service -Name $serviceName

    if ($serviceObject.Status -eq 'Stopped')
    {
        Write-Verbose -Message "$serviceName is in Stopped State."
    }
    else
    {
        Write-Error -Message "$serviceName is in unexpected state: $($serviceObject.Status)"
    }

    if ($serviceObject.CanPauseAndContinue -eq $false)
    {
        Write-Verbose -Message "$serviceName has correct CanPauseAndContinue State."
    }
    else
    {
        Write-Error -Message "$serviceName has unexpected CanPauseAndContinue: $($serviceObject.CanPauseAndContinue)"
    }

    if ($serviceObject.CanShutdown -eq $false)
    {
        Write-Verbose -Message "$serviceName has correct CanShutdown State."
    }
    else
    {
        Write-Error -Message "$serviceName has unexpected CanShutdown: $($serviceObject.CanShutdown)"
    }
   
    if ($serviceObject.CanStop -eq $false)
    {
        Write-Verbose -Message "$serviceName has correct CanStop State."
    }
    else
    {
        Write-Error -Message "$serviceName has unexpected CanStop: $($serviceObject.CanStop)"
    }

    if ($serviceObject.ServiceType -eq "Win32OwnProcess")
    {
        Write-Verbose -Message "$serviceName will run as Win32OwnProcess."
    }
    else
    {
        Write-Error -Message "$serviceName has unexpected ServiceType: $($serviceObject.ServiceType)"
    }


    # For windows 2008 R2 + sp1 Get-Service cmdlet does not populate StartType
    if ($serviceObject.PSObject.Properties['StartType'])
    {
        if ($serviceObject.StartType -eq "Automatic")
        {
            Write-Verbose -Message "$serviceName will be started Automatically."
        }
        else
        {
            Write-Warning -Message "$serviceName has unexpected StartType: $($serviceObject.StartType)"
        }
    }
    else
    {
        # Configure recovery of the service during failure. We need to look for the value of the start type because the type will be localized based on
        # the language of the machine. Since we're only looking for one startType: '(DELAYED)' we can just search for that and assume that if we can't
        # find it then it is configured incorrectly.
        $ServiceStartType = ([string](sc.exe qc $serviceName | Select-String '(DELAYED)')).Split(' ',[System.StringSplitOptions]::RemoveEmptyEntries)[-1]
        if ($ServiceStartType -imatch '(DELAYED)')
        {
            Write-Verbose -Message "$serviceName will be started Automatically."
        }
        else
        {
            Write-Warning -Message "$serviceName has unexpected StartType or the StartType cannot be found on the object. StartType: $ServiceStartType"
        }
    }

    # Also validate some service properties from the registry database of scm. 
    $serviceRegistryData = Get-ItemProperty hklm:\SYSTEM\CurrentControlSet\Services\$serviceName

    if ($serviceRegistryData.ImagePath -eq $serviceBinaryPathCommand)
    {
        Write-Verbose -Message "$serviceName Binary is Installed Correctly."
    }
    else
    {
        Write-Error -Message "$serviceName binary is not Installed correctly: $($serviceRegistryData.ImagePath)"
    }
    if ($serviceRegistryData.ObjectName -eq "LocalSystem")
    {
        Write-Verbose -Message "$serviceName will run under LocalSystem Account."
    }
    else
    {
       Write-Error -Message "$serviceName has unexpected AccountType: $($serviceRegistryData.ObjectName)"
    }

    if ($ServiceType -eq "GC")
    {

        if ($serviceRegistryData.DisplayName -eq $script:GCServiceDisplayName)
        {
            Write-Verbose -Message "$serviceName has correct Display Name."
        }
        else
        {
            Write-Error -Message "$serviceName has unexpected DisplayName:  $($serviceRegistryData.DisplayName)"
        }
        if ($serviceRegistryData.Description -eq $script:GCServiceDescription)
        {
            Write-Verbose -Message "$serviceName has correct Description Data."
        }
        else
        {
            Write-Error -Message "$serviceName has unexpected Description: $($serviceRegistryData.Description)"
        }
    }
    elseif ($ServiceType -eq "GCArc")
    {
        if ($serviceRegistryData.DisplayName -eq $script:GCArcServiceDisplayName)
        {
            Write-Verbose -Message "$serviceName has correct Display Name."
        }
        else
        {
            Write-Error -Message "$serviceName has unexpected DisplayName:  $($serviceRegistryData.DisplayName)"
        }
        if ($serviceRegistryData.Description -eq $script:GCArcServiceDescription)
        {
            Write-Verbose -Message "$serviceName has correct Description Data."
        }
        else
        {
            Write-Error -Message "$serviceName has unexpected Description: $($serviceRegistryData.Description)"
        }
    }
    elseif ($ServiceType -eq "Extension")
    {
        if ($serviceRegistryData.DisplayName -eq $script:ExtDisplayName)
        {
            Write-Verbose -Message "$serviceName has correct Display Name."
        }
        else
        {
            Write-Error -Message "$serviceName has unexpected DisplayName:  $($serviceRegistryData.DisplayName)"
        }
        if ($serviceRegistryData.Description -eq $script:ExtDescription)
        {
            Write-Verbose -Message "$serviceName has correct Description Data."
        }
        else
        {
            Write-Error -Message "$serviceName has unexpected Description: $($serviceRegistryData.Description)"
        }
    }

}

<#
.Synopsis
   Get Guest Config data path.
#>
function Get-GuestConfigDataPath
{
    [CmdletBinding()]
    param ()

    return Join-Path $env:ProgramData 'GuestConfig'
}

<#
.Synopsis
   Set Acl permissions on given path
#>
function Set-AclPermissions
{
    [CmdletBinding()]
    Param
    (
        [Parameter()]
        [string]
        $ServiceType,

        [Parameter()]
        [string]
        $Path
    )

    try
    {
        Write-Verbose -Message "Attempting to set ACL permissions on the path '$Path' with PowerShell..."

        if ($ServiceType -eq 'GC')
        {
            Write-Verbose -Message "Using Get-Acl"
            $acl = Get-Acl $Path
        }
        else
        {
            # Ext deployment fails in azure with "[System.IO.DirectoryInfo] does not contain a method named 'GetAccessControl'" error
            # So we are calling this only for Hybrid scenarios.
            Write-Verbose -Message "Using Get-Item GetAccessControl"
            $acl = (Get-Item $Path).GetAccessControl('Access')
        }

        # Removing inherited access rules
        Write-Verbose -Message "Clearing existing ACL permissions"
        $acl.SetAccessRuleProtection($True, $False)

        # Adding new access rules for the target directory
        Write-Verbose -Message "Setting ACL permissions for the built-in Administrator"
        $BuiltinAdminSID = New-Object System.Security.Principal.SecurityIdentifier 'S-1-5-32-544' #Built-in Administrators SID
        $rule =  New-Object System.Security.AccessControl.FileSystemAccessRule($BuiltinAdminSID, 'FullControl', 'ContainerInherit, ObjectInherit', 'None', 'Allow')
        $acl.AddAccessRule($rule)
        Set-Acl $Path $acl

        Write-Verbose -Message "Setting ACL permissions for the Local System"
        $BuiltinLocalSystemSID = New-Object System.Security.Principal.SecurityIdentifier 'S-1-5-18' #Local System SID
        $rule =  New-Object System.Security.AccessControl.FileSystemAccessRule($BuiltinLocalSystemSID, 'FullControl', 'ContainerInherit, ObjectInherit', 'None', 'Allow')
        $acl.AddAccessRule($rule)
        Set-Acl $Path $acl

        Write-Verbose -Message "Suceeded setting ACL permissions with PowerShell"
    }
    catch
    {
        Write-Verbose -Message "Failed to set ACL permissions with PowerShell. Attempting with icacls..."

        # For windows 2008 R2 + sp1 start-process with -Wait parameter does not work. Hence sleep for 5 sec instead.
        $osVersion=[Environment]::OSVersion.Version
        if (($osVersion.Major -eq 6) -and ($osVersion.Minor -eq 1) -and ($osVersion.Build -le 7601))
        {
            $processGrantAdminUserAccess = Start-Process icacls.exe -ArgumentList "$Path /grant *S-1-5-32-544:(OI)(CI)F" -PassThru
            $processGrantLocalSystemUserAccess = Start-Process icacls.exe -ArgumentList "$Path /grant *S-1-5-18:(OI)(CI)F" -PassThru
            Start-Sleep -Seconds 5
        }
        else
        {
            $processGrantAdminUserAccess = Start-Process icacls.exe -ArgumentList "$Path /grant *S-1-5-32-544:(OI)(CI)F" -PassThru -Wait
            $processGrantLocalSystemUserAccess = Start-Process icacls.exe -ArgumentList "$Path /grant *S-1-5-18:(OI)(CI)F" -PassThru -Wait
        }

        if ($null -eq $processGrantAdminUserAccess)
        {
            Write-Error "Failed to start icacls.exe process to set Administrator user permission on $Path."
        }

        if ($null -eq $processGrantLocalSystemUserAccess)
        {
            Write-Error "Failed to start icacls.exe process to set LocalSystem user permission on $Path."
        }

        # on 2008R2 ExitCode is not set.
        if (($processGrantAdminUserAccess.ExitCode -ne 0) -and ($null -ne $processGrantAdminUserAccess.ExitCode))
        {
            Write-Error "icacls.exe failed to set Administrator user permission on $Path. Exit code: $($processGrantAdminUserAccess.ExitCode)"
        }

        if (($processGrantLocalSystemUserAccess.ExitCode -ne 0) -and ($null -ne $processGrantLocalSystemUserAccess.ExitCode))
        {
            Write-Error "icacls.exe failed to set LocalSystem user permission on $Path. Exit code: $($processGrantLocalSystemUserAccess.ExitCode)"
        }
    }
}

<#
    .SYNOPSIS
        Start the GC Service. Report Failure if service is not able to start. 

    .Example
       Start-ServiceInternal
#>
Function Start-ServiceInternal {
    [CmdletBinding()]
    Param(
        [Parameter()]
        [string]
        $ServiceType = "GC"
    )

    Write-Verbose -Message "In Start-ServiceInternal"
    if ($ServiceType -eq "GC")
    {
        $serviceName = $global:GCServiceName
    }
    elseif ($ServiceType -eq "GCArc")
    {
        $serviceName = $global:GCArcServiceName
    }
    elseif ($ServiceType -eq "Extension")
    {
        $serviceName = $global:ExtServiceName
    }

    # Start GC Timer Service, may be retry on failure.
    Start-Service $serviceName 

    $serviceObject = Get-Service -Name $serviceName

    if ($serviceObject.Status -eq 'Running')
    {
        Write-Verbose -Message "$serviceName is running."
    }
    else
    {
        Write-Error "$serviceName can not be started."
    }
}

<#
    .SYNOPSIS
        Stop the GC service and then uninstall it.

    .Example
       Uninstall-ServiceInternal
#>
Function Uninstall-ServiceInternal {
    [CmdletBinding()]
    Param(
        [Parameter()]
        [string]
        $ServiceType = "GC"
    )

    Write-Verbose -Message "In Uninstall-ServiceInternal"

    if ($ServiceType -eq "GC")
    {
        $serviceName = $global:GCServiceName
    }
    elseif ($ServiceType -eq "GCArc")
    {
        $serviceName = $global:GCArcServiceName
    }
    elseif ($ServiceType -eq "Extension")
    {
        $serviceName = $global:ExtServiceName
    }

    # Unregister GC Service
    $timeOut = [timespan]::FromMinutes(5)
    $stopRetry = [DateTime]::Now.Add($timeOut)
    $secondsBetweenRetry = 3
    Stop-Service $serviceName -ErrorAction SilentlyContinue -ErrorVariable stopTimeError
    if (Get-Service $serviceName -ErrorAction SilentlyContinue)
    {
        if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue)
        {
            while (((Get-Service -Name $serviceName).Status -ne 'Stopped') -and ([dateTime]::Now -le $stopRetry))
            {
                Write-Verbose "Wait for service to stop" -Verbose
                Start-Sleep -Seconds $secondsBetweenRetry
            }
        }

        $serviceObject = Get-Service -Name $serviceName
        
        if ($serviceObject.Status -eq 'Stopped')
        {
            Write-Verbose -Message "$serviceName is stopped."
            sc.exe delete $serviceName
        }
        else
        {
            Write-Error "$serviceName can not be Uninstalled because we are not able to stop it."
        }
    }
    else
    {
        Write-Verbose "Service already stopped" -Verbose
    }

    # some basic validation to check service is Uninstalled. 
    $serviceRegistryExists = Get-ItemProperty hklm:\SYSTEM\CurrentControlSet\Services\$serviceName -ErrorAction SilentlyContinue

    if ($serviceRegistryExists -ne $null) {

        # sometimes the registry clean up does not happen right away. Hence do retry for the check.
        while (($serviceRegistryExists -ne $null) -and ([dateTime]::Now -le $stopRetry))
        {
            Start-Sleep -Seconds $secondsBetweenRetry
            $serviceRegistryExists = Get-ItemProperty hklm:\SYSTEM\CurrentControlSet\Services\$serviceName -ErrorAction SilentlyContinue
        }

        # if service registry entry still exist.
        if ($serviceRegistryExists -ne $null)
        {
            Write-Error "$serviceName is not Uninstalled correctly. Information is Present in Registry Database."
        }
    }

    $getService = Get-Service $serviceName -ErrorAction SilentlyContinue
    
    if ($getService -ne $null)
    {
          Write-Error "$serviceName is not Uninstalled correctly. Service is reporting status."
    }
}

Function CheckServiceExists
{
    [CmdletBinding()]
    Param(
        [Parameter()]
        [string]
        $ServiceName = $global:GCServiceName
    )
    if (Get-Service $serviceName -ErrorAction SilentlyContinue)
    {
        return $true
    }
    return $false
}

function Invoke-ScriptWithRetry {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, Position = 0)]
        [ScriptBlock] $Script = {},

        [Parameter()]
        [int] $RetryCount = 3
    )
    $results = $null
    $exceptionObject = $null
    $keepRetrying = $true

    Write-Verbose "Invoke-ScriptWithRetry:: Start time : $((Get-Date).ToString())"

    for($i = 0; (($i -lt $RetryCount) -and ($keepRetrying -eq $true)); $i++) {
        try {
            $exceptionObject = $null
            $results = Invoke-Command -ScriptBlock $Script
            $keepRetrying = $false
        }
        catch
        {
            Write-Verbose "Retry Count $i"
            Write-Warning "$_"
            $exceptionObject = $_
        }

        try {
            # Processor utilization
            $processorObj = Get-WmiObject -Class win32_processor -ErrorAction SilentlyContinue
            if($processorObj -ne $null) {
                $cpuUsage = ($processorObj | Measure-Object -Property LoadPercentage -Average | Select-Object Average).Average
                Write-Verbose "CPU Usage : '$($cpuUsage)%'"
            }

            # Memory utilization
            $computerMemory = Get-WmiObject -Class win32_operatingsystem -ErrorAction SilentlyContinue
            if($computerMemory -ne $null) {
                $memory = ((($computerMemory.TotalVisibleMemorySize - $computerMemory.FreePhysicalMemory)*100)/ $computerMemory.TotalVisibleMemorySize)
                Write-Verbose "Memory Usage : '$($memory)%'"
            }
        }
        catch
        {
            Write-Warning "Failed to compute Memory/CPU usage. Error : $_"
        }
    }

    Write-Verbose "Invoke-ScriptWithRetry:: End time : $((Get-Date).ToString())"

    if($exceptionObject -ne $null) {
        throw $exceptionObject
    }

    return $results
}
# SIG # Begin signature block
# MIInvwYJKoZIhvcNAQcCoIInsDCCJ6wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBI071bx7Qv02kc
# Weh4vvZKzNcnYWFqPkN3/xZky5fV4aCCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGZ8wghmbAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIMssvOiwDaWmswar3r1SHuBO
# B1NIyHWOe9fjKR9gTfsZMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAurqLR9T6TfXUUnbq0D8DlgzSkRKjA5KISDa2f0PwZG+KSm0utU/3cM0s
# PZSIBF3ZaxG5wMQwXGiw+IDYGdcuUWpQuemVCZGkB9E6fkiVg1T58GuT2PASswuz
# YQ/VDgV9MJdQ/m825LHBDPlFeQjM1vZfFOlphiyJljCFooSKFdhiqAm2VXGU/xDS
# 7CSU7W9/BKJxw65rwTy6DKXnZWu4pv3nfjJhfmYspRiV9wwoOI5X4pZRGCEThHH1
# UmTMPx7N1mpCHY7RyZFnaKIFWER1PM41UiS5YvSwgzG1Axa67dvjw73TlR10T7AN
# oxkK6BMxpzeFla9lKidN2Lnr22LGYqGCFykwghclBgorBgEEAYI3AwMBMYIXFTCC
# FxEGCSqGSIb3DQEHAqCCFwIwghb+AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFZBgsq
# hkiG9w0BCRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCDZ40uAzAE4DAso5cMHK4iVkMJ+i5WF6TROLzjWaY9kXAIGZbqlGyxB
# GBMyMDI0MDIxNDA0NDEzOC4xNDlaMASAAgH0oIHYpIHVMIHSMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNO
# OkZDNDEtNEJENC1EMjIwMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloIIReDCCBycwggUPoAMCAQICEzMAAAHimZmV8dzjIOsAAQAAAeIwDQYJ
# KoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjMx
# MDEyMTkwNzI1WhcNMjUwMTEwMTkwNzI1WjCB0jELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3Bl
# cmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpGQzQxLTRC
# RDQtRDIyMDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBALVjtZhV+kFmb8cKQpg2mzis
# DlRI978Gb2amGvbAmCd04JVGeTe/QGzM8KbQrMDol7DC7jS03JkcrPsWi9WpVwsI
# ckRQ8AkX1idBG9HhyCspAavfuvz55khl7brPQx7H99UJbsE3wMmpmJasPWpgF05z
# ZlvpWQDULDcIYyl5lXI4HVZ5N6MSxWO8zwWr4r9xkMmUXs7ICxDJr5a39SSePAJR
# IyznaIc0WzZ6MFcTRzLLNyPBE4KrVv1LFd96FNxAzwnetSePg88EmRezr2T3HTFE
# lneJXyQYd6YQ7eCIc7yllWoY03CEg9ghorp9qUKcBUfFcS4XElf3GSERnlzJsK7s
# /ZGPU4daHT2jWGoYha2QCOmkgjOmBFCqQFFwFmsPrZj4eQszYxq4c4HqPnUu4hT4
# aqpvUZ3qIOXbdyU42pNL93cn0rPTTleOUsOQbgvlRdthFCBepxfb6nbsp3fcZaPB
# fTbtXVa8nLQuMCBqyfsebuqnbwj+lHQfqKpivpyd7KCWACoj78XUwYqy1HyYnStT
# me4T9vK6u2O/KThfROeJHiSg44ymFj+34IcFEhPogaKvNNsTVm4QbqphCyknrwBy
# qorBCLH6bllRtJMJwmu7GRdTQsIx2HMKqphEtpSm1z3ufASdPrgPhsQIRFkHZGui
# hL1Jjj4Lu3CbAmha0lOrAgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQURIQOEdq+7Qds
# lptJiCRNpXgJ2gUwHwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYD
# VR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9j
# cmwvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwG
# CCsGAQUFBwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIw
# MjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcD
# CDAOBgNVHQ8BAf8EBAMCB4AwDQYJKoZIhvcNAQELBQADggIBAORURDGrVRTbnulf
# sg2cTsyyh7YXvhVU7NZMkITAQYsFEPVgvSviCylr5ap3ka76Yz0t/6lxuczI6w7t
# Xq8n4WxUUgcj5wAhnNorhnD8ljYqbck37fggYK3+wEwLhP1PGC5tvXK0xYomU1nU
# +lXOy9ZRnShI/HZdFrw2srgtsbWow9OMuADS5lg7okrXa2daCOGnxuaD1IO+65E7
# qv2O0W0sGj7AWdOjNdpexPrspL2KEcOMeJVmkk/O0ganhFzzHAnWjtNWneU11WQ6
# Bxv8OpN1fY9wzQoiycgvOOJM93od55EGeXxfF8bofLVlUE3zIikoSed+8s61NDP+
# x9RMya2mwK/Ys1xdvDlZTHndIKssfmu3vu/a+BFf2uIoycVTvBQpv/drRJD68eo4
# 01mkCRFkmy/+BmQlRrx2rapqAu5k0Nev+iUdBUKmX/iOaKZ75vuQg7hCiBA5xIm5
# ZIXDSlX47wwFar3/BgTwntMq9ra6QRAeS/o/uYWkmvqvE8Aq38QmKgTiBnWSS/uV
# PcaHEyArnyFh5G+qeCGmL44MfEnFEhxc3saPmXhe6MhSgCIGJUZDA7336nQD8fn4
# y6534Lel+LuT5F5bFt0mLwd+H5GxGzObZmm/c3pEWtHv1ug7dS/Dfrcd1sn2E4gk
# 4W1L1jdRBbK9xwkMmwY+CHZeMSvBMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJ
# mQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1
# WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjK
# NVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhg
# fWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJp
# rx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/d
# vI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka9
# 7aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKR
# Hh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9itu
# qBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyO
# ArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItb
# oKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6
# bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6t
# AgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQW
# BBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacb
# UzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYz
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnku
# aHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIA
# QwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2
# VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwu
# bWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYt
# MjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/q
# XBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6
# U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVt
# I1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis
# 9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTp
# kbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0
# sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138e
# W0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJ
# sWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7
# Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0
# dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQ
# tB1VM1izoXBm8qGCAtQwggI9AgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxh
# bmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpG
# QzQxLTRCRDQtRDIyMDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAFpuZafp0bnpJdIhfiB1d8pTohm+ggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOl2RZcwIhgPMjAyNDAyMTQwMzQ2MzFaGA8yMDI0MDIxNTAzNDYzMVowdDA6Bgor
# BgEEAYRZCgQBMSwwKjAKAgUA6XZFlwIBADAHAgEAAgIJLTAHAgEAAgIRljAKAgUA
# 6XeXFwIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAID
# B6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAEOJqsPs/b6SSpT8gbDD
# +1ipkORsU6h9JAm8917n2opsv3riEbRABLAOdoSW3blDM9f8rUT9/ZQqqVVXuRa2
# F7t9MakQXkJBv57FxifzvhNFFBqa7LtCPJ/g+3Zq+tW7mfTnldVPZOUGkSnSYWk0
# tyuIbAeDGVJ3Bg9FjGrQx7rnMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTACEzMAAAHimZmV8dzjIOsAAQAAAeIwDQYJYIZIAWUDBAIB
# BQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQx
# IgQgL8XRSKiEEdff/RUbLLpo9zJydwW9TxJHwv5xCCQjii0wgfoGCyqGSIb3DQEJ
# EAIvMYHqMIHnMIHkMIG9BCAriSpKEP0muMbBUETODoL4d5LU6I/bjucIZkOJCI9/
# /zCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# JjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB4pmZ
# lfHc4yDrAAEAAAHiMCIEIEsOmtuGVU3+5gWG9N3mOJVYgNCDG+JYMV0dluvcGFoy
# MA0GCSqGSIb3DQEBCwUABIICADOyNVzDSWYSsN6gcdkQmndEAAaoLDGKNvv9Z9jC
# 7OChm1jRffV8iSYZt4d8xOhEu9PF3We3Pkh+W3Qa4gzJ0cUWyHbylb2L95znVKPY
# 9mov8Eu2S+reNfNGssq0g4UEN9ODQMqiv/SnSgl+46b1cHnyuZiZXYOjp9VU4TDe
# sT43zC1Uyl7ERJhLSacushhni6MIb7AMiUGxLMoVIiTMXRsDZ7EyryM9tBwh87ud
# ubRhC9/YdzszrXwHacs9TkXYPHWWzwTHhlOSOhh5FKMx6T98iBdAgq2dI+G0RH0H
# M4OJJ/XNFxS9a/BR0SmyimFIbf+82EHmPdjRlC1aUDSFIxk5PTv0svjr7EUt6uur
# ry9DILwdcWNMhIYEIpoVzWYtEHuasw2hjGGnOAobM4wyTQdsp70SoddNLaYc9ZDd
# Ii2lhSuYwYmiwklnJcSTkFyafLgYF0ZZtOePgDFVTMj5VyGPwnc1hKjZI+AEn1ba
# kK5ny7A8ILRJ2g8o6n6OsiwfBIzqEJfEeG2KbOEoGuTks/hmetpwCiRSvSIxbfWN
# SU/66eC/PPNH77Cq4Rtgo2TknXcRyzmrmwyc+GjSSMXd70v9joInsA0vfJ4jmZIR
# EZhru/dMxX6d5ZdFufkFcSTlsJB0B2CGVsnwKTkUohjhvYn0q0GxNvZIGcQdDPUF
# NqwW
# SIG # End signature block
