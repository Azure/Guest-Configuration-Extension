#!/bin/bash
# 
# This script disables DSC on Linux by stopping the DSC service.
# 

DSC_HOME_PATH="$PWD"
SERVICE_SCRIPTS_FOLDER_PATH="$DSC_HOME_PATH/service_scripts"
SERVICE_CONTROLLER_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/gc_service_controller"
SERVICE_CONTROLLER_PATH_EXT="$SERVICE_SCRIPTS_FOLDER_PATH/ext_service_controller"

print_error() {
  echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@" >&2
}

check_result() {
    if [ $1 -ne 0 ]; then
        print_error $2
        exit $1
    fi
}

stop_dsc_service() {
    if [ $# -ne 0 ] && [ $1 = "Extension" ]; then
        $SERVICE_CONTROLLER_PATH_EXT stop
        check_result $? "Stopping the EXT service failed"
    else
        $SERVICE_CONTROLLER_PATH stop
        check_result $? "Stopping the DSC service failed"
    fi
    
}

disable_dsc() {
    stop_dsc_service $1
}

disable_dsc $1
