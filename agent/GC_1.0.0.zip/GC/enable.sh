#!/bin/bash
# 
# This script enables GC on Linux by starting the gcd service.
#

GC_HOME_PATH="$PWD"
SERVICE_SCRIPTS_FOLDER_PATH="$GC_HOME_PATH/service_scripts"
SERVICE_CONTROLLER_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/gc_service_controller"

LINUX_DISTRO=""

print_error() {
  echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@" >&2
}

check_result() {
    if [ $1 -ne 0 ]; then
        print_error $2
        exit $1
    fi
}

start_gc_service() {
    $SERVICE_CONTROLLER_PATH start
    check_result $? "Starting the GC service failed"
}

enable_gc() {
    start_gc_service
}


get_linux_distro() {
    if [[ ! -z $LINUX_DISTRO ]]; then
        return
    fi

    VERSION_OUTPUT=$(cat /proc/version)

    if [[ $VERSION_OUTPUT = *"Ubuntu"* ]]; then
        LINUX_DISTRO="Ubuntu"
    elif [[ $VERSION_OUTPUT = *"Red Hat"* ]]; then
        LINUX_DISTRO="Red Hat"
    elif [[ $VERSION_OUTPUT = *"SUSE"* ]]; then
        LINUX_DISTRO="SUSE"
    elif [[ $VERSION_OUTPUT = *"CentOS"* ]]; then
        LINUX_DISTRO="CentOS"
    elif [[ $VERSION_OUTPUT = *"Debian"* ]]; then
        LINUX_DISTRO="Debian"
    elif [[ $VERSION_OUTPUT = *"Mariner"* ]]; then
        LINUX_DISTRO="Mariner"
    else
        print_error "Unexpected Linux distribution. Expected Linux distributions include only Ubuntu, Red Hat, SUSE, CentOS, Mariner and Debian."
        # Exit with error code 51 (The extension is not supported on this OS)
        exit 51
    fi

    echo "Linux distribution is $LINUX_DISTRO."
}

install_curl_dependency() {
    get_linux_distro

    case "$LINUX_DISTRO" in

    "Ubuntu")
        echo "Checking for package 'curl'..."
        if [ $(dpkg-query -W -f='${Status}' curl 2>/dev/null | grep -c "ok installed") -eq 0 ]; then
            echo "Installing package 'curl'..."
            export DEBIAN_FRONTEND=noninteractive
            apt -yq install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        else
            echo "Package 'curl' is already installed."
        fi
        ;;
    "Red Hat")
        echo "Checking for package 'curl'..."
        if yum list installed curl >/dev/null 2>&1; then
            echo "Package 'curl' is already installed."
        else
            echo "Installing package 'curl'..."
            yum -y install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        fi
        ;;
    "SUSE")
        echo "Checking for package 'curl'..."
        if zypper se -ix curl >/dev/null 2>&1; then
            echo "Package 'curl' is already installed."
        else
            echo "Installing package 'curl'..."
            zypper -n install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        fi
        ;;
    "CentOS")
        echo "Checking for package 'curl'..."
        if yum list installed curl >/dev/null 2>&1; then
            echo "Package 'curl' is already installed."
        else
            echo "Installing package 'curl'..."
            yum -y install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        fi
        ;;
    "Mariner")
        if command -v yum >/dev/null 2>&1; then
            PACKAGE_MANAGER="yum"
        elif command -v dnf >/dev/null 2>&1; then
            PACKAGE_MANAGER="dnf"
        else
            print_error "Failed to find a suitable package manager for Mariner."
            exit 1
        fi

        echo "Checking for package 'curl'... using $PACKAGE_MANAGER..."
        if $PACKAGE_MANAGER list installed curl >/dev/null 2>&1; then
            echo "Package 'curl' is already installed."
        else
            echo "Installing package 'curl'..."
            $PACKAGE_MANAGER -y install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        fi
        ;;
    "Debian")
        echo "Checking for package 'curl'..."
        if [ $(dpkg-query -W -f='${Status}' curl 2>/dev/null | grep -c "ok installed") -eq 0 ]; then
            echo "Installing package 'curl'..."
            export DEBIAN_FRONTEND=noninteractive
            apt -yq install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        else
            echo "Package 'curl' is already installed."
        fi
        ;;
    *) echo "Could not install curl dependency packages for unexpected Linux distribution '$LINUX_DISTRO'."
        exit 1 
        ;;
    esac
}

echo "Checking for curl dependency"
install_curl_dependency
check_result $? "Installation of curl failed"

enable_gc