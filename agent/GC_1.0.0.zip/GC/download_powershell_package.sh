#!/bin/bash
# 
# This script downloads the PowerShell package on Linux.
# 

# GC path (Ex - /var/lib/waagent/Microsoft.GuestConfiguration.ConfigurationforLinux-1.26.4/GCAgent/GC) 
PS_HOME_PATH=$1
if [ "x$PS_HOME_PATH" = "x" ]; then
    echo 'Missing argument. Usage: "<script> <GC_BIN_PATH>"'
    exit 2
fi
PS_HOME_PATH=`realpath $PS_HOME_PATH`

PACKAGE_NAME="Pwsh-7.2-preview-dsc-support.tar.xz"
EXPECTED_SHA256_CHECKSUM="2e58ab4999ab3607bce042f43809e88e189103e3165d7da3c65fdf787d9593a6"
MAX_DOWNLOAD_RETRY_COUNT=10

# In priority order. Default is WCUS.
AVAILABLE_AZURE_STORAGE_REGIONS=('wcus'
    'we'
    'ase'
    'brs'
    'cid'
    'eus2'
    'ne'
    'scus'
    'uks'
    'wus2')

check_result() {
    if [ $1 -ne 0 ]; then
        echo $2
        rm -rf $PS_HOME_PATH/$PACKAGE_NAME
        exit $1
    fi
}

get_azure_storage_url() {
    CURRENT_REGION=$1
    AZURE_STORAGE_ENDPOINT="oaasguestconfig${CURRENT_REGION}s1"
    AZURE_STORAGE_URL="https://${AZURE_STORAGE_ENDPOINT}.blob.core.windows.net/powershellpkgs"
}

rotate_azure_storage_url() {
    RETRY_NUM=$1

    NUM_AVAILABLE_REGIONS=${#AVAILABLE_AZURE_STORAGE_REGIONS[@]}

    CURRENT_REGION_INDEX=$(( RETRY_NUM % NUM_AVAILABLE_REGIONS ))
    CURRENT_REGION=${AVAILABLE_AZURE_STORAGE_REGIONS[$CURRENT_REGION_INDEX]}
    get_azure_storage_url $CURRENT_REGION
}

download_package() {
    PACKAGE_NAME=$1
    PACKAGE_URL=$2
    DOWNLOAD_PACKAGE_NAME=$3
    DOWNLOAD_SUCCEEDED=false
    TOTAL_RETRY_SEC=0
    RETRY_SLEEP_INTERVAL_SEC=5
    RETRY_MAX_SEC=60
    CURL_MAX_SEC=120

    while [ $TOTAL_RETRY_SEC -lt $RETRY_MAX_SEC ] &&  [ "$DOWNLOAD_SUCCEEDED" = false ]; do
        if [ $TOTAL_RETRY_SEC -gt 0 ]; then
            echo "Retrying after $RETRY_SLEEP_INTERVAL_SEC seconds"
            sleep $RETRY_SLEEP_INTERVAL_SEC
        fi

        echo "Downloading package '$PACKAGE_NAME' from the URL '$PACKAGE_URL'"
        cd $PS_HOME_PATH

        # "curl" is present on all GC supported operating systems.
        # install_inspec.sh already takes dependency on "curl".
        if command -v curl &> /dev/null
        then
            echo "Downloading with curl"
            HTTP_RESPONSE_CODE=$(curl -sS -w "%{http_code}" -o $DOWNLOAD_PACKAGE_NAME -m $CURL_MAX_SEC $PACKAGE_URL)
            RESPONSE_CODE=$?
        elif command -v wget &> /dev/null # Use wget if curl is not available
        then
            echo "Downloading with wget"
            HTTP_RESPONSE_CODE=$(wget --server-response --tries=5 --timeout=$CURL_MAX_SEC $PACKAGE_URL  2>&1 | awk '/^  HTTP/{print $2}')
            RESPONSE_CODE=$?
        fi

        if [ $RESPONSE_CODE -eq 0 ]; then
            if [ $HTTP_RESPONSE_CODE -ne 200 ]; then
                echo "Download of package '$PACKAGE_NAME' failed with the HTTP response code '$HTTP_RESPONSE_CODE'"
            else
                DOWNLOAD_SUCCEEDED=true
            fi
        else
            echo "Download of package '$PACKAGE_NAME' failed with the response code '$RESPONSE_CODE'"
        fi

        TOTAL_RETRY_SEC+=$RETRY_SLEEP_INTERVAL_SEC
    done

    if [ "$DOWNLOAD_SUCCEEDED" = true ]; then
        echo "Download of package '$PACKAGE_NAME' succeeded"
        return 0
    else
        echo "Download of package '$PACKAGE_NAME' failed after retrying for $RETRY_MAX_SEC seconds"
        return 1
    fi
}

test_sha256_checksums_match() {
    FILE_TO_CHECK=$1
    EXPECTED_SHA256_CHECKSUM=$2

    echo "Comparing checksums with sha256sum"
    ACTUAL_SHA256_CHECKSUM=`sha256sum $FILE_TO_CHECK | awk '{ print $1 }'`
    test "x$ACTUAL_SHA256_CHECKSUM" = "x$EXPECTED_SHA256_CHECKSUM"
    CHECKSUM_RESULT=$?

    if [ $CHECKSUM_RESULT -ne 0 ]; then
        echo "PowerShell package checksum does not match. actual_checksum:$ACTUAL_SHA256_CHECKSUM expected_checksum:$EXPECTED_SHA256_CHECKSUM"
        return 1
    else
        echo "PowerShell package checksum matches expected checksum"
        return 0
    fi
}

download_and_validate_package() {
    PACKAGE_NAME=$1
    EXPECTED_SHA256_CHECKSUM=$2

    DOWNLOAD_URL="$AZURE_STORAGE_URL/$PACKAGE_NAME"

    download_package $PACKAGE_NAME $DOWNLOAD_URL $PACKAGE_NAME
    if [ $? -ne 0 ]; then
        return 1
    else
        test_sha256_checksums_match "$PACKAGE_NAME" "$EXPECTED_SHA256_CHECKSUM"
        if [ $? -ne 0 ]; then
            echo "Removing downloaded $PACKAGE_NAME file since checksums do not match"
            rm -rf $PS_HOME_PATH/$PACKAGE_NAME
            return 2
        fi
    fi
    
    return 0
}

download_and_validate_package_with_retries() {
    PACKAGE_NAME=$1
    EXPECTED_SHA256_CHECKSUM=$2

    NUM_RETRIES=0
    DOWNLOAD_RESULT=1
 
    while [ $NUM_RETRIES -lt $MAX_DOWNLOAD_RETRY_COUNT ] && [ $DOWNLOAD_RESULT -ne 0 ]; do
        rotate_azure_storage_url $NUM_RETRIES
        download_and_validate_package $PACKAGE_NAME $EXPECTED_SHA256_CHECKSUM
        DOWNLOAD_RESULT=$?
        ((NUM_RETRIES++))
    done

    check_result $DOWNLOAD_RESULT "Failed to download PowerShell"
    echo "Successfully downloaded PowerShell"
}

install_powershell() {
    if [ ! -f "$PS_HOME_PATH/pwsh" ] ; then
        download_and_validate_package_with_retries $PACKAGE_NAME $EXPECTED_SHA256_CHECKSUM
        tar xvf $PACKAGE_NAME >/dev/null 2>&1
        PACKAGE_NAME_WITHOUT_EXT=`basename $PACKAGE_NAME .tar.xz`
        rm -rf $PS_HOME_PATH/$PACKAGE_NAME_WITHOUT_EXT/libmi.so # Don't copy libmi from PowerShell
        cp -rf $PS_HOME_PATH/$PACKAGE_NAME_WITHOUT_EXT/* $PS_HOME_PATH
        rm -rf $PS_HOME_PATH/$PACKAGE_NAME_WITHOUT_EXT* # Remove the downloaded payload, temp directory

        if [ ! -f "$PS_HOME_PATH/pwsh" ]; then
            echo "Couldn't find pwsh in the PowerShell package"
            exit 1
        fi
        echo "PowerShell payload is downloaded successfully"
    else
        echo "PowerShell is already installed"
    fi
}

install_powershell
check_result $? "Failed to download PowerShell"

