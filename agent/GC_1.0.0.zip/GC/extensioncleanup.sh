#!/bin/bash
# 
# This script removes extensions from Linux Arc machines.
# 

GC_HOME_PATH=$(dirname "$0")
CLEANUP_EXTENSION_PATH="$GC_HOME_PATH/em_extension_cleanup"

if [ $# -eq 0 ]; then 
    echo "No Arguments passed for cleanup tool. Run this script with '-h' for info on what is accepted"
	exit 1
fi

verify_privileges()
{
    if [ `id -u` -ne 0 ]; then
        echo "Must have root privileges for this operation" >& 2
        exit 1
    fi
}

is_dsc_running()
{
    verify_privileges

    # If systemd lives here, then we have a systemd unit file
    if pidof systemd 1> /dev/null 2> /dev/null; then
        echo "Getting status via systemd"
        if /bin/systemctl status extd 2>/dev/null | grep "Active:.*(running)"; then
            echo "Extension service is running and must be stopped before running the cleanup tool."
            return 1
        fi
    elif [ -x /sbin/initctl -a -f /etc/init/extd.conf ]; then
        echo "Getting status via initctl"
        if /sbin/initctl status extd 2>/dev/null | grep "start/"; then 
            echo "Extension service is running and must be stopped before running the cleanup tool."
            return 1
        fi
    elif [ -x /bin/systemctl ]; then
        echo "Getting status via systemctl"
        if /bin/systemctl status extd 2>/dev/null | grep "Active:.*(running)"; then 
            echo "Extension service is running and must be stopped before running the cleanup tool."
            return 1
        fi
    elif [ -x /sbin/service ]; then
        echo "Getting status via system service"
        if /sbin/service extd status 2>/dev/null | grep "start/"; then
            echo "Extension service is running and must be stopped before running the cleanup tool."
            return 1
        fi
    elif [ -x /usr/sbin/service ]; then
        echo "Getting status via usr system service"
        if /usr/sbin/service extd status 2>/dev/null | grep "start/"; then
            echo "Extension service is running and must be stopped before running the cleanup tool."
            return 1
        fi
    elif [ -x /usr/sbin/invoke-rc.d ]; then
        echo "Getting status via invoke-rc"
        if /usr/sbin/invoke-rc.d extd status 2>/dev/null | grep "start/"; then
            echo "Extension service is running and must be stopped before running the cleanup tool."
            return 1
        fi
    else
        get_system_service_controller
        case "$SYSTEM_SERVICE_CONTROLLER" in
        "systemd")
            echo "Getting status via systemd"
            if /bin/systemctl status extd 2>/dev/null | grep "Active:.*(running)"; then
                echo "Extension service is running and must be stopped before running the cleanup tool."
                return 1
            fi
            ;;
        "upstart")
            echo "Getting status via initctl"
            if /sbin/initctl status extd 2>/dev/null | grep "start/"; then 
                echo "Extension service is running and must be stopped before running the cleanup tool."
                return 1
            fi
            ;;
        *) echo "Unrecognized system service controller to retrieve EXT service status."
            ;;
        esac
    fi

    echo "EXT service is not running."
    return 0
}

is_dsc_running

if [ $? -ne 0 ]; then
    exit 1
fi

parameter1=$1
if [ "$parameter1" = "h" ] || [ "$parameter1" = "n" ] || [ "$parameter1" = "a" ] || [ "$parameter1" = "l" ]; then 
    parameter1="-$parameter1"
elif [ "$parameter1" = "help" ] || [ "$parameter1" = "name" ] || [ "$parameter1" = "all" ] || [ "$parameter1" = "list" ]; then 
    parameter1="--$parameter1"
fi

if [ $# -gt 1 ]; then 
    parameter2=$2
    ${CLEANUP_EXTENSION_PATH} $parameter1 $parameter2
else
    ${CLEANUP_EXTENSION_PATH} $parameter1
fi
