#!/bin/bash
#
# This script is used to update GC on Linux.
# Nothing needs to be migrated at the moment.
#
BASEDIR=$(dirname "$0")
echo $BASEDIR
find /var/lib/waagent/ -name gc.config -exec cp {} $BASEDIR  \; >/dev/null 2>&1

exit 0