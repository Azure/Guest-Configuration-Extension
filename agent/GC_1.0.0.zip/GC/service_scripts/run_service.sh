#!/bin/bash
# 
# This script starts gc service
# 

echo "Start service process"
<EXE_FILE_PATH> &
PID=$!

echo "service pid = $PID"

sigquit()
{
   echo "Stopping service process $PID"
   kill $PID 2>/dev/null
   echo "Waiting for service pid=$PID"
   wait $PID 2>/dev/null
   echo "Finished waiting on pid=$PID"
   exit 0
}

trap 'sigquit' QUIT TERM STOP KILL

echo "Waiting for service pid=$PID"
wait $PID 2>/dev/null
echo "Finished waiting on pid=$PID"
exit 0